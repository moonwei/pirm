<?php
/*
 * This file is part of PHPUnit.
 *
 * (c) Sebastian Bergmann <sebastian@phpunit.de>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
// PHPUnit_Framework_TestCase itself does not exist. :-)
require __DIR__ . '/../../../bootstrap.php';

const GITHUB_ISSUE = 797;
