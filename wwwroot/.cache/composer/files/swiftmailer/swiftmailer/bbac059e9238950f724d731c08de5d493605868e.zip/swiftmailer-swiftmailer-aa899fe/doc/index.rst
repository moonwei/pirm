Swiftmailer
===========

.. toctree::
    :maxdepth: 2

    introduction
    messages
    headers
    sending
    plugins
    japanese
